class PessoaFisica {
    private String nome;
    private String cpf;
    private int idade;

    public PessoaFisica(String nome, String cpf, int idade) {
        this.nome = nome;
        this.cpf = cpf;
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public int getIdade() {
        return idade;
    }

    public void exibirInformacoes() {
        System.out.println("Nome: " + nome);
        System.out.println("CPF: " + cpf);
        System.out.println("Idade: " + idade);
    }
}

class Desempregado extends PessoaFisica {
    public Desempregado(String nome, String cpf, int idade) {
        super(nome, cpf, idade);
    }

    @Override
    public void exibirInformacoes() {
        super.exibirInformacoes();
        System.out.println("Status: Desempregado");
    }
}

class Empregado extends PessoaFisica {
    private double salario;

    public Empregado(String nome, String cpf, int idade, double salario) {
        super(nome, cpf, idade);
        this.salario = salario;
    }

    public double getSalario() {
        return salario;
    }

    @Override
    public void exibirInformacoes() {
        super.exibirInformacoes();
        System.out.println("Status: Empregado");
        System.out.println("Salário: R$ " + salario);
    }
}

class Mensalista extends Empregado {
    public Mensalista(String nome, String cpf, int idade, double salario) {
        super(nome, cpf, idade, salario);
    }

    @Override
    public void exibirInformacoes() {
        super.exibirInformacoes();
        System.out.println("Tipo: Mensalista");
    }
}

class Comissionado extends Empregado {
    private double comissao;

    public Comissionado(String nome, String cpf, int idade, double salario, double comissao) {
        super(nome, cpf, idade, salario);
        this.comissao = comissao;
    }

    public double getComissao() {
        return comissao;
    }

    @Override
    public void exibirInformacoes() {
        super.exibirInformacoes();
        System.out.println("Tipo: Comissionado");
        System.out.println("Comissão: R$ " + comissao);
    }
}

class Horista extends Empregado {
    private double valorHora;
    private int horasTrabalhadas;

    public Horista(String nome, String cpf, int idade, double valorHora, int horasTrabalhadas) {
        super(nome, cpf, idade, 0);  
        this.valorHora = valorHora;
        this.horasTrabalhadas = horasTrabalhadas;
    }

    public double calcularSalario() {
        return valorHora * horasTrabalhadas;
    }

    @Override
    public void exibirInformacoes() {
        super.exibirInformacoes();
        System.out.println("Tipo: Horista");
        System.out.println("Salário: R$ " + calcularSalario());
    }
}

class Tarefeiro extends Empregado {
    private int numeroTarefas;
    private double valorPorTarefa;

    public Tarefeiro(String nome, String cpf, int idade, int numeroTarefas, double valorPorTarefa) {
        super(nome, cpf, idade, 0); 
        this.numeroTarefas = numeroTarefas;
        this.valorPorTarefa = valorPorTarefa;
    }

    public double calcularSalario() {
        return numeroTarefas * valorPorTarefa;
    }

    @Override
    public void exibirInformacoes() {
        super.exibirInformacoes();
        System.out.println("Tipo: Tarefeiro");
        System.out.println("Salário: R$ " + calcularSalario());
    }
}

public class Main {
    public static void main(String[] args) {
        PessoaFisica pessoa1 = new Desempregado("João Silva", "123.456.789-00", 30);
        PessoaFisica pessoa2 = new Mensalista("Maria Oliveira", "987.654.321-00", 25, 3000.00);
        PessoaFisica pessoa3 = new Comissionado("Carlos Souza", "111.222.333-44", 40, 2500.00, 500.00);
        PessoaFisica pessoa4 = new Horista("Ana Pereira", "555.666.777-88", 35, 20.00, 160);
        PessoaFisica pessoa5 = new Tarefeiro("Luís Santos", "999.888.777-66", 28, 50, 30.00);

        pessoa1.exibirInformacoes();
        System.out.println();
        pessoa2.exibirInformacoes();
        System.out.println();
        pessoa3.exibirInformacoes();
        System.out.println();
        pessoa4.exibirInformacoes();
        System.out.println();
        pessoa5.exibirInformacoes();
    }
}
