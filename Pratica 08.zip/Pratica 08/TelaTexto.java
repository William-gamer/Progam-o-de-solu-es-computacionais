import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaTexto {
    public static void main(String[] args) {

        JFrame frame = new JFrame("Campo de Texto");
        frame.setSize(300, 200);  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);


        JLabel labelTexto = new JLabel("Texto:");
        labelTexto.setBounds(30, 30, 100, 20);  
        frame.add(labelTexto);

        JTextField campoTexto = new JTextField();
        campoTexto.setBounds(30, 60, 200, 30);  
                frame.add(campoTexto);

        JButton botaoMostrar = new JButton("Mostrar");
        botaoMostrar.setBounds(30, 100, 90, 30);  
        frame.add(botaoMostrar);

        JButton botaoLimpar = new JButton("Limpar");
        botaoLimpar.setBounds(130, 100, 90, 30); 
        frame.add(botaoLimpar);

        JButton botaoSair = new JButton("Sair");
        botaoSair.setBounds(30, 140, 200, 30);  
        frame.add(botaoSair);


        botaoMostrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String texto = campoTexto.getText();
                JOptionPane.showMessageDialog(frame, texto, "Conteúdo do Campo", JOptionPane.INFORMATION_MESSAGE);
            }
        });


        botaoLimpar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                campoTexto.setText("");  
                
            }
        });


        botaoSair.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);  
            }
        });


        frame.setVisible(true);
    }
}
