import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaRelogio {
    private static Relogio relogio = new Relogio();  
    private static JLabel mostrador = new JLabel();

    public static void main(String[] args) {
        JFrame frame = new JFrame("Relógio");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);


        mostrador.setBounds(100, 20, 100, 30);
        mostrador.setText(relogio.mostra());  
        frame.add(mostrador);

        JButton botaoTicTac = new JButton("TicTac");
        botaoTicTac.setBounds(30, 70, 100, 30);
        frame.add(botaoTicTac);

        JButton botaoHora = new JButton("Hora");
        botaoHora.setBounds(140, 70, 100, 30);
        frame.add(botaoHora);

        JButton botaoMinuto = new JButton("Minuto");
        botaoMinuto.setBounds(30, 110, 100, 30);
        frame.add(botaoMinuto);


        botaoTicTac.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                relogio.ticTac();  
                mostrador.setText(relogio.mostra());  
            }
        });


        botaoHora.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String horaStr = JOptionPane.showInputDialog("Digite a hora (0 a 23):");
                int hora = Integer.parseInt(horaStr);
                relogio.setHora(hora);
                mostrador.setText(relogio.mostra());
            }
        });


        botaoMinuto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String minutoStr = JOptionPane.showInputDialog("Digite o minuto (0 a 59):");
                int minuto = Integer.parseInt(minutoStr);
                relogio.setMinuto(minuto);
                mostrador.setText(relogio.mostra());
            }
        });


        frame.setVisible(true);
    }
}
