import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calculadora {

    private static String textoAtual = "";
    private static String operador = "";
    private static int resultado = 0;

    public static void main(String[] args) {

        JFrame frame = new JFrame("Calculadora");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 600);
        frame.setLayout(new BorderLayout());


        JTextField display = new JTextField();
        display.setFont(new Font("Arial", Font.PLAIN, 24));
        display.setEditable(false);
        display.setHorizontalAlignment(JTextField.RIGHT);
        frame.add(display, BorderLayout.NORTH);


        JPanel painelBotoes = new JPanel();
        painelBotoes.setLayout(new GridLayout(4, 4));


        String[] botoes = {
            "7", "8", "9", "/",
            "4", "5", "6", "*",
            "1", "2", "3", "-",
            "0", "C", "=", "+"
        };


        for (String textoBotao : botoes) {
            JButton botao = new JButton(textoBotao);
            botao.setFont(new Font("Arial", Font.PLAIN, 24));
            botao.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String comando = e.getActionCommand();

                    if (comando.equals("C")) {
                        textoAtual = "";
                        operador = "";
                        resultado = 0;
                    } else if (comando.equals("=")) {
                        calcularResultado();
                    } else if (comando.equals("/") || comando.equals("*") || comando.equals("-") || comando.equals("+")) {
                        if (!textoAtual.isEmpty()) {
                            operador = comando;
                            resultado = Integer.parseInt(textoAtual);
                            textoAtual = "";
                        }
                    } else {
                        textoAtual += comando;
                    }

                    display.setText(textoAtual.isEmpty() ? String.valueOf(resultado) : textoAtual);
                }
            });
            painelBotoes.add(botao);
        }


        frame.add(painelBotoes, BorderLayout.CENTER);


        frame.setVisible(true);
    }

    private static void calcularResultado() {
        try {
            int numAtual = Integer.parseInt(textoAtual);

            switch (operador) {
                case "+":
                    resultado += numAtual;
                    break;
                case "-":
                    resultado -= numAtual;
                    break;
                case "*":
                    resultado *= numAtual;
                    break;
                case "/":
                    if (numAtual != 0) {
                        resultado /= numAtual;
                    } else {
                        JOptionPane.showMessageDialog(null, "Erro: Divisão por zero!");
                        resultado = 0;
                    }
                    break;
                default:
                    break;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Erro: Entrada inválida.");
            resultado = 0;
        }
        textoAtual = "";
    }
}
