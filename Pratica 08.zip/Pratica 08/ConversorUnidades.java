import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ConversorUnidades {
    public static void main(String[] args) {

        JFrame frame = new JFrame("Conversor de Unidades");
        frame.setSize(400, 250);  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);  


        JLabel labelEntrada = new JLabel("Digite um valor em centímetros:");
        labelEntrada.setBounds(30, 30, 250, 20);  
        frame.add(labelEntrada);

        JTextField campoEntrada = new JTextField();
        campoEntrada.setBounds(30, 60, 150, 30);  
        frame.add(campoEntrada);

        JButton botaoConverter = new JButton("Converter");
        botaoConverter.setBounds(30, 100, 150, 30);  
        frame.add(botaoConverter);

        JLabel resultado = new JLabel("Resultado: ");
        resultado.setBounds(30, 140, 350, 60);  
        frame.add(resultado);


        botaoConverter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String valorTexto = campoEntrada.getText();
                try {
                    double valorCm = Double.parseDouble(valorTexto);  
                    if (valorCm < 0) {
                        resultado.setText("Por favor, insira um valor positivo.");
                    } else {

                        double metros = valorCm / 100;
                        double milimetros = valorCm * 10;
                        double quilometros = valorCm / 100000;

                        resultado.setText(String.format("<html>Metros: %.2f<br>Milímetros: %.2f<br>Quilômetros: %.5f</html>", metros, milimetros, quilometros));
                    }
                } catch (NumberFormatException ex) {
                    resultado.setText("Por favor, insira um valor numérico válido.");
                }
            }
        });

        frame.setVisible(true);
    }
}
