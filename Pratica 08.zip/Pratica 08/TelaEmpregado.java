import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaEmpregado {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Hierarquia de Empregados");
        frame.setSize(300, 250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel label = new JLabel("Selecione um tipo de Empregado:");
        label.setBounds(20, 20, 250, 20);
        frame.add(label);

        JButton btnMensalista = new JButton("Mensalista");
        btnMensalista.setBounds(20, 60, 120, 30);
        frame.add(btnMensalista);

        JButton btnComissionado = new JButton("Comissionado");
        btnComissionado.setBounds(160, 60, 120, 30);
        frame.add(btnComissionado);

        JButton btnHorista = new JButton("Horista");
        btnHorista.setBounds(20, 100, 120, 30);
        frame.add(btnHorista);

        JButton btnTarefeiro = new JButton("Tarefeiro");
        btnTarefeiro.setBounds(160, 100, 120, 30);
        frame.add(btnTarefeiro);


        btnMensalista.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Você selecionou o tipo Mensalista");
            }
        });

        btnComissionado.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Você selecionou o tipo Comissionado");
            }
        });

        btnHorista.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Você selecionou o tipo Horista");
            }
        });

        btnTarefeiro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Você selecionou o tipo Tarefeiro");
            }
        });


        frame.setVisible(true);
    }
}
