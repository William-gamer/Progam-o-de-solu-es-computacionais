import javax.swing.*;
import java.util.ArrayList;

public class CadastroApp {


    public static class Cliente {
        private String nome;
        private String fone;
        private int id;


        public Cliente(String nome, String fone, int id) {
            this.nome = nome;
            this.fone = fone;
            this.id = id;
        }


        public String getNome() {
            return nome;
        }

        public String getFone() {
            return fone;
        }

        public int getId() {
            return id;
        }


        public void setNome(String nome) {
            this.nome = nome;
        }

        public void setFone(String fone) {
            this.fone = fone;
        }

        public void setId(int id) {
            this.id = id;
        }


        @Override
        public String toString() {
            return "Cliente ID: " + id + " - Nome: " + nome + " - Fone: " + fone;
        }
    }


    public static class BancoDeClientes {
        private ArrayList<Cliente> clientes;


        public BancoDeClientes() {
            clientes = new ArrayList<>();
        }


        public void inserirCliente(Cliente cliente) {
            clientes.add(cliente);
        }


        public boolean removerCliente(int id) {
            for (int i = 0; i < clientes.size(); i++) {
                if (clientes.get(i).getId() == id) {
                    clientes.remove(i);
                    return true;
                }
            }
            return false;
        }


        public boolean alterarCliente(int id, String novoNome, String novoFone) {
            for (Cliente cliente : clientes) {
                if (cliente.getId() == id) {
                    cliente.setNome(novoNome);
                    cliente.setFone(novoFone);
                    return true;
                }
            }
            return false;
        }


        public Cliente listarCliente(int id) {
            for (Cliente cliente : clientes) {
                if (cliente.getId() == id) {
                    return cliente;
                }
            }
            return null;  
        }


        public ArrayList<Cliente> listarTodosClientes() {
            return clientes;
        }
    }


    public static void main(String[] args) {
        BancoDeClientes banco = new BancoDeClientes();
        int opcao;

        do {
            String menu = "1. Inserir cliente\n"
                        + "2. Remover cliente\n"
                        + "3. Alterar cliente\n"
                        + "4. Listar dados de um cliente\n"
                        + "5. Listar todos os clientes\n"
                        + "6. Sair";
            opcao = Integer.parseInt(JOptionPane.showInputDialog(menu));

            switch (opcao) {
                case 1: 
                    String nome = JOptionPane.showInputDialog("Digite o nome do cliente:");
                    String fone = JOptionPane.showInputDialog("Digite o telefone do cliente:");
                    int id = Integer.parseInt(JOptionPane.showInputDialog("Digite o ID do cliente:"));
                    Cliente novoCliente = new Cliente(nome, fone, id);
                    banco.inserirCliente(novoCliente);
                    JOptionPane.showMessageDialog(null, "Cliente inserido com sucesso!");
                    break;

                case 2: 
                    int idRemover = Integer.parseInt(JOptionPane.showInputDialog("Digite o ID do cliente para remover:"));
                    boolean removido = banco.removerCliente(idRemover);
                    if (removido) {
                        JOptionPane.showMessageDialog(null, "Cliente removido com sucesso!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Cliente não encontrado!");
                    }
                    break;

                case 3: 
                    int idAlterar = Integer.parseInt(JOptionPane.showInputDialog("Digite o ID do cliente para alterar:"));
                    String novoNome = JOptionPane.showInputDialog("Digite o novo nome do cliente:");
                    String novoFone = JOptionPane.showInputDialog("Digite o novo telefone do cliente:");
                    boolean alterado = banco.alterarCliente(idAlterar, novoNome, novoFone);
                    if (alterado) {
                        JOptionPane.showMessageDialog(null, "Cliente alterado com sucesso!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Cliente não encontrado!");
                    }
                    break;

                case 4: 
                    int idListar = Integer.parseInt(JOptionPane.showInputDialog("Digite o ID do cliente para listar:"));
                    Cliente cliente = banco.listarCliente(idListar);
                    if (cliente != null) {
                        JOptionPane.showMessageDialog(null, "Dados do cliente: " + cliente.toString());
                    } else {
                        JOptionPane.showMessageDialog(null, "Cliente não encontrado!");
                    }
                    break;

                case 5: 
                    ArrayList<Cliente> todosClientes = banco.listarTodosClientes();
                    if (todosClientes.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Nenhum cliente cadastrado!");
                    } else {
                        StringBuilder listaClientes = new StringBuilder("Clientes cadastrados:\n");
                        for (Cliente c : todosClientes) {
                            listaClientes.append(c.toString()).append("\n");
                        }
                        JOptionPane.showMessageDialog(null, listaClientes.toString());
                    }
                    break;

                case 6: 
                    JOptionPane.showMessageDialog(null, "Saindo do sistema...");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida! Tente novamente.");
                    break;
            }
        } while (opcao != 6);
    }
}
