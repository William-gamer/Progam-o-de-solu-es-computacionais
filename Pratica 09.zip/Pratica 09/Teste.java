import javax.swing.*;
import java.util.ArrayList;

class Caixa {
    private String corredor;
    private int posicao;
    private double peso;
    private String dono;

    public Caixa(String corredor, int posicao, double peso, String dono) {
        this.corredor = corredor;
        this.posicao = posicao;
        this.peso = peso;
        this.dono = dono;
    }

    public String getCorredor() {
        return corredor;
    }

    public int getPosicao() {
        return posicao;
    }

    public double getPeso() {
        return peso;
    }

    public String getDono() {
        return dono;
    }


    public void setCorredor(String corredor) {
        this.corredor = corredor;
    }

    public void setPosicao(int posicao) {
        this.posicao = posicao;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void setDono(String dono) {
        this.dono = dono;
    }


    @Override
    public String toString() {
        return "Caixa do dono " + dono + " - Corredor: " + corredor + ", Posição: " + posicao + ", Peso: " + peso;
    }
}


class Deposito {
    private ArrayList<Caixa> caixas;


    public Deposito() {
        caixas = new ArrayList<>();
    }


    public void adicionarCaixa(Caixa caixa) {
        caixas.add(caixa);
    }


    public boolean removerCaixa(String dono) {
        for (int i = 0; i < caixas.size(); i++) {
            if (caixas.get(i).getDono().equals(dono)) {
                caixas.remove(i);
                return true;
            }
        }
        return false;
    }


    public int procurarCaixa(String dono) {
        for (int i = 0; i < caixas.size(); i++) {
            if (caixas.get(i).getDono().equals(dono)) {
                return i;  
            }
        }
        return -1;  
    }


    public boolean mudarCaixa(String dono, String novoCorredor, int novaPosicao) {
        int index = procurarCaixa(dono);
        if (index != -1) {
            Caixa caixa = caixas.get(index);
            caixa.setCorredor(novoCorredor);
            caixa.setPosicao(novaPosicao);
            return true;
        }
        return false;
    }


    public ArrayList<Caixa> listarCaixasPesadas(double pesoMinimo) {
        ArrayList<Caixa> pesadas = new ArrayList<>();
        for (Caixa caixa : caixas) {
            if (caixa.getPeso() > pesoMinimo) {
                pesadas.add(caixa);
            }
        }
        return pesadas;
    }
}


public class Teste {
    public static void main(String[] args) {
        Deposito deposito = new Deposito();
        int opcao;

        do {
            String menu = "1. Adicionar caixa\n"
                        + "2. Remover caixa\n"
                        + "3. Procurar caixa\n"
                        + "4. Mudar caixa\n"
                        + "5. Listar caixas pesadas\n"
                        + "6. Sair";
            opcao = Integer.parseInt(JOptionPane.showInputDialog(menu));

            switch (opcao) {
                case 1: 
                    String dono = JOptionPane.showInputDialog("Digite o nome do dono da caixa:");
                    String corredor = JOptionPane.showInputDialog("Digite o corredor da caixa:");
                    int posicao = Integer.parseInt(JOptionPane.showInputDialog("Digite a posição da caixa:"));
                    double peso = Double.parseDouble(JOptionPane.showInputDialog("Digite o peso da caixa:"));
                    Caixa novaCaixa = new Caixa(corredor, posicao, peso, dono);
                    deposito.adicionarCaixa(novaCaixa);
                    JOptionPane.showMessageDialog(null, "Caixa adicionada com sucesso!");
                    break;

                case 2: 
                    String donoRemover = JOptionPane.showInputDialog("Digite o nome do dono da caixa para remover:");
                    boolean removida = deposito.removerCaixa(donoRemover);
                    if (removida) {
                        JOptionPane.showMessageDialog(null, "Caixa removida com sucesso!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Caixa não encontrada!");
                    }
                    break;

                case 3: 
                    String donoProcurar = JOptionPane.showInputDialog("Digite o nome do dono da caixa para procurar:");
                    int indice = deposito.procurarCaixa(donoProcurar);
                    if (indice != -1) {
                        JOptionPane.showMessageDialog(null, "Caixa encontrada na posição " + indice + ": " + Deposito.caixas.get(indice).toString());
                    } else {
                        JOptionPane.showMessageDialog(null, "Caixa não encontrada!");
                    }
                    break;

                case 4: 
                    String donoMudar = JOptionPane.showInputDialog("Digite o nome do dono da caixa para mudar:");
                    String novoCorredor = JOptionPane.showInputDialog("Digite o novo corredor:");
                    int novaPosicao = Integer.parseInt(JOptionPane.showInputDialog("Digite a nova posição:"));
                    boolean mudou = deposito.mudarCaixa(donoMudar, novoCorredor, novaPosicao);
                    if (mudou) {
                        JOptionPane.showMessageDialog(null, "Caixa movida com sucesso!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Caixa não encontrada para mover.");
                    }
                    break;

                case 5: 
                    double pesoMinimo = Double.parseDouble(JOptionPane.showInputDialog("Digite o peso mínimo para listar as caixas:"));
                    ArrayList<Caixa> pesadas = deposito.listarCaixasPesadas(pesoMinimo);
                    if (pesadas.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Nenhuma caixa com peso maior que " + pesoMinimo);
                    } else {
                        StringBuilder listaPesadas = new StringBuilder("Caixas mais pesadas que " + pesoMinimo + ":\n");
                        for (Caixa caixa : pesadas) {
                            listaPesadas.append(caixa.toString()).append("\n");
                        }
                        JOptionPane.showMessageDialog(null, listaPesadas.toString());
                    }
                    break;

                case 6: 
                    JOptionPane.showMessageDialog(null, "Saindo do sistema...");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida, tente novamente.");
                    break;
            }
        } while (opcao != 6);
    }
}
