import java.util.ArrayList;
import java.util.Scanner;

public class BlocoDeNotasApp {


    public static class BlocoDeNotas {
        private ArrayList<String> notas;


        public BlocoDeNotas() {
            notas = new ArrayList<>();
        }


        public void inserirNota(String nota) {
            notas.add(nota);
        }


        public boolean removerNota(int indice) {
            if (indice >= 0 && indice < notas.size()) {
                notas.remove(indice);
                return true;
            }
            return false;
        }


        public boolean alterarNota(int indice, String novaNota) {
            if (indice >= 0 && indice < notas.size()) {
                notas.set(indice, novaNota);
                return true;
            }
            return false;
        }


        public void listarNotas() {
            if (notas.isEmpty()) {
                System.out.println("Não há notas para listar.");
            } else {
                System.out.println("Notas:");
                for (int i = 0; i < notas.size(); i++) {
                    System.out.println(i + 1 + ". " + notas.get(i));
                }
            }
        }
    }


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BlocoDeNotas bloco = new BlocoDeNotas();
        int opcao;

        do {
            System.out.println("\nMenu:");
            System.out.println("1) Inserir uma nota");
            System.out.println("2) Remover uma nota");
            System.out.println("3) Alterar uma nota");
            System.out.println("4) Listar todas as notas");
            System.out.println("5) Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    System.out.print("Digite a nota: ");
                    String notaInserida = scanner.nextLine();
                    bloco.inserirNota(notaInserida);
                    System.out.println("Nota inserida com sucesso!");
                    break;

                case 2:
                    bloco.listarNotas();
                    System.out.print("Digite o número da nota para remover: ");
                    int indiceRemover = scanner.nextInt() - 1;
                    if (bloco.removerNota(indiceRemover)) {
                        System.out.println("Nota removida com sucesso!");
                    } else {
                        System.out.println("Índice inválido.");
                    }
                    break;

                case 3:
                    bloco.listarNotas();
                    System.out.print("Digite o número da nota para alterar: ");
                    int indiceAlterar = scanner.nextInt() - 1;
                    scanner.nextLine(); 
                    if (indiceAlterar >= 0 && indiceAlterar < bloco.notas.size()) {
                        System.out.print("Digite a nova nota: ");
                        String novaNota = scanner.nextLine();
                        if (bloco.alterarNota(indiceAlterar, novaNota)) {
                            System.out.println("Nota alterada com sucesso!");
                        } else {
                            System.out.println("Falha ao alterar a nota.");
                        }
                    } else {
                        System.out.println("Índice inválido.");
                    }
                    break;

                case 4:
                    bloco.listarNotas();
                    break;

                case 5:
                    System.out.println("Saindo do sistema...");
                    break;

                default:
                    System.out.println("Opção inválida! Tente novamente.");
                    break;
            }

        } while (opcao != 5);

        scanner.close();
    }
}
