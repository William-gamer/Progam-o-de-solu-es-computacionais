public class Solucao1e {
    public static void main(String[] args) {
        // Definindo os caracteres diretamente
        char milhar = '2';  // Exemplo de milhar
        char centena = '0'; // Exemplo de centena
        char dezena = '2';  // Exemplo de dezena
        char unidade = '4'; // Exemplo de unidade
        
        // Concatena os caracteres em uma String
        String resultado = "" + milhar + centena + dezena + unidade;
        
        // Imprime o resultado
        System.out.println("O numero e: " + resultado);
    }
}
