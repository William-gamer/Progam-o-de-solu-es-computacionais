public class Solucao1t {
    public static void main(String[] args) {
        int dividendo = 10;
        int divisor = 3;
        
        
        int quociente = dividendo / divisor;
        int resto = dividendo % divisor;
        
        System.out.println("Dividendo: " + dividendo);
        System.out.println("Divisor: " + divisor);
        System.out.println("Quociente: " + quociente);
        System.out.println("Resto: " + resto);
    }
}

