public class Solucao1o {
    public static void main(String[] args) {
        
        String frase1 = "Esta e a primeira frase";
        String frase2 = "Aqui esta a segunda frase";
        String frase3 = "E finalmente, a terceira frase";
        
        
        String metade1_1 = frase1.substring(0, frase1.length() / 2);
        String metade1_2 = frase1.substring(frase1.length() / 2);
        String metade2_1 = frase2.substring(0, frase2.length() / 2);
        String metade2_2 = frase2.substring(frase2.length() / 2);
        String metade3_1 = frase3.substring(0, frase3.length() / 2);
        String metade3_2 = frase3.substring(frase3.length() / 2);
        
        
        String fraseEmbaralhada = metade2_1 + metade3_2 + metade2_2 + metade1_1 + metade3_1 + metade1_2;
        
        
        String concatenacaoFrases = frase1 + " " + frase2 + " " + frase3;
        
        
        System.out.println("Concatenacao das frases originais:");
        System.out.println(concatenacaoFrases);
        
        System.out.println("\nFrase embaralhada:");
        System.out.println(fraseEmbaralhada);
    }
}
