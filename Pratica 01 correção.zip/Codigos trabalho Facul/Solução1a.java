public class Palavras { 
public static void main(String[] args) { 
String palavra1 = "primeira"; 
String palavra2 = "segunda"; 
String palavra3 = "terceira"; 
System.out.println(palavra3 + " " + palavra2 + " " + palavra1);          
                                        } 
}