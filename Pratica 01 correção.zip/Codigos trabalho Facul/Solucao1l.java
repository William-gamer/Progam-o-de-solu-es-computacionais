public class Solucao1l {
    public static void main(String[] args) {
        
        double graus = 45.0;  
        
        
        double radianos = Math.toRadians(graus);
        
        
        double seno = Math.sin(radianos);
        double cosseno = Math.cos(radianos);
        double tangente = Math.tan(radianos);
        
        
        double secante = (cosseno != 0) ? 1 / cosseno : Double.NaN;
        double cossecante = (seno != 0) ? 1 / seno : Double.NaN;
        double cotangente = (tangente != 0) ? 1 / tangente : Double.NaN;
        
        
        System.out.printf("Angulo: %.2f graus%n", graus);
        System.out.printf("Seno: %.4f%n", seno);
        System.out.printf("Cosseno: %.4f%n", cosseno);
        System.out.printf("Tangente: %.4f%n", tangente);
        System.out.printf("Secante: %.4f%n", secante);
        System.out.printf("Cossecante: %.4f%n", cossecante);
        System.out.printf("Cotangente: %.4f%n", cotangente);
    }
}
