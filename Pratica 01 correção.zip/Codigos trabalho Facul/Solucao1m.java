public class Solucao1m {
    public static void main(String[] args) {
        
        double numero = 100.0;  
        
        
        if (numero <= 0) {
            System.out.println("O número deve ser maior que zero.");
            return;
        }
        
        
        double logaritmo = Math.log10(numero);
        
        
        System.out.printf("O logaritmo na base 10 de %.2f é %.4f%n", numero, logaritmo);
    }
}
