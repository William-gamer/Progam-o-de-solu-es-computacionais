public class Solucao1j {
    public static void main(String[] args) {
       
        double valorInicial = 100.00; 
        double taxaJuros = 10.0;      
        int numeroMeses = 8;          
        
        double valorFinal = valorInicial * Math.pow((1 + taxaJuros / 100), numeroMeses);

        
        System.out.printf("Após %d meses, a dívida de R$ %.2f será de R$ %.2f%n", numeroMeses, valorInicial, valorFinal);
    }
}
