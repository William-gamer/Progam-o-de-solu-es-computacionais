public class Solucao1h {
    public static void main(String[] args) {
        int numeroInteiro = 125;
           double quadrado = Math.pow((double) numeroInteiro, 2);
           System.out.println("O quadrado de " + numeroInteiro + " e " + quadrado);
    }
}
