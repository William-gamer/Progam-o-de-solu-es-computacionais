import javax.swing.JOptionPane;

public class Solucao1i {
    public static void main(String[] args) {
        
        String str1 = JOptionPane.showInputDialog("Digite a primeira String:");
        String str2 = JOptionPane.showInputDialog("Digite a segunda String:");
        String str3 = JOptionPane.showInputDialog("Digite a terceira String:");
        
        
        if (str1 == null) str1 = "";
        if (str2 == null) str2 = "";
        if (str3 == null) str3 = "";
        
        
        int comprimento1 = str1.length();
        int comprimento2 = str2.length();
        int comprimento3 = str3.length();
        
        
        int somaComprimentos = comprimento1 + comprimento2 + comprimento3;
        
        
        JOptionPane.showMessageDialog(null, "A soma dos comprimentos das Strings é: " + somaComprimentos);
    }
}
