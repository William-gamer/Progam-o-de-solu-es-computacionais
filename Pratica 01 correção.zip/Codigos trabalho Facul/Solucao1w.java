public class Solucao1w {
    public static void main(String[] args) {
        
        double diagonalMaior = 8; 
        double diagonalMenor = 5;  

        
        double area = (diagonalMaior * diagonalMenor) / 2;

        
        System.out.println("Diagonal Maior: " + diagonalMaior);
        System.out.println("Diagonal Menor: " + diagonalMenor);
        System.out.println("Área do losango: " + area);
    }
}
