import javax.swing.JOptionPane;

public class Solucao1k {
    public static void main(String[] args) {
    
      String input = JOptionPane.showInputDialog("Digite um número inteiro com 3 casas decimais (ex: 123456):");        
        
        
        int numero = Integer.parseInt(input);
        
        
        
        int dezenas = (numero / 10) %10;
        
        
        
        JOptionPane.showMessageDialog(null, "O algarismo da casa das dezenas é: " + dezenas);
     }
}