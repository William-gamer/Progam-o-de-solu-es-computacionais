import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Solucao1e {
    public static void main(String[] args) {
        // Criação de um objeto BufferedReader para ler a entrada do usuário
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        try {
            // Leitura dos quatro números inteiros como caracteres
            System.out.println("Digite o milhar:");
            char milhar = (char) reader.read();

            // Limpar o buffer de entrada para consumir o caractere de nova linha
            reader.readLine(); 

            System.out.println("Digite a centena:");
            char centena = (char) reader.read();

            // Limpar o buffer de entrada para consumir o caractere de nova linha
            reader.readLine(); 

            System.out.println("Digite a dezena:");
            char dezena = (char) reader.read();

            // Limpar o buffer de entrada para consumir o caractere de nova linha
            reader.readLine(); 

            System.out.println("Digite a unidade:");
            char unidade = (char) reader.read();

            // Limpar o buffer de entrada para consumir o caractere de nova linha
            reader.readLine(); 

            // Concatenação dos caracteres em uma String
            String resultado = "" + milhar + centena + dezena + unidade;

            // Impressão do resultado
            System.out.println("O número formado é: " + resultado);

        } catch (IOException e) {
            // Tratamento de exceções de entrada/saída
            System.err.println("Erro ao ler a entrada: " + e.getMessage());
        }
    }
}
