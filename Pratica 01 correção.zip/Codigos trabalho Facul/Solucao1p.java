public class Solucao1p {
    public static void main(String[] args) {
    
    int data = 180924;
    
    
    int dia = data / 10000;
    int mes = (data / 100) % 100;
    int ano = data % 100;
    
    
    System.out.println("Dia: " + dia);
    System.out.println("Mes: " + mes);
    System.out.println("Ano: " + ano);
    }
} 