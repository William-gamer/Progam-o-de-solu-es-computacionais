public class Solucao1s {
    public static void main(String[] args) {
    
    final double PI = 3.14159;
    
    
    double raio = 26.0;
    
    
    double area = PI * raio * raio;
    
    
    System.out.println("A area do circulo e: " + area);
    
    }
}