public class Solucao1g {
 public static void main(String[] args){
  
  double base, altura, areaRetangulo;
  
  base = 10.34;
  altura =20;
  areaRetangulo = base * altura;
  
  System.out.println("A area de um retangulo de base = " + base);
  System.out.println("e altura " + altura);
  System.out.println("e " + areaRetangulo);
  
  }
 }