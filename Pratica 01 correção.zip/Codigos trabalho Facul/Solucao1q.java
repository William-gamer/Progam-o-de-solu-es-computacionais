public class Solucao1q {
    public static void main(String[] args) {
    
    String data = "18/09/2024";
    
    String[] partes = data.split("/");
    
    String dia = partes[0];
    String mes = partes[1];
    String ano = partes[2];
    
    System.out.println("Dia : " + dia);
    System.out.println("Mes : " + mes);
    System.out.println("Ano : " + ano); 
    }
}