public class Solucao1v {
    public static void main(String[] args) {
    
    double base = 10;
    double altura = 20;
    
    double area = (base * altura) / 2;
    
    System.out.println("Base: " + base);
    System.out.println("Altura " + altura);
    System.out.println("AreaDoTriangulo " + area);
    
   }
}