public class Solucao1f {
    public static void main(String[] args) {
        // Defina a idade aqui
        int idade = 36; // Substitua 36 pela sua idade

        // Calcule o número de dias vividos
        double diasVividos = calcularDiasVividos(idade);

        // Exiba o resultado
        System.out.printf("Número aproximado de dias vividos: %.2f\n", diasVividos);
    }

    public static double calcularDiasVividos(int idade) {
        // Considera 365,25 dias por ano para levar em conta anos bissextos
        double diasPorAno = 365.25;

        // Calcule o número de dias vividos
        double totalDiasVividos = idade * diasPorAno;

        // Retorne o resultado
        return totalDiasVividos;
    }
}
