public class Solucao1n {
    public static void main(String[] args) {
        
        double numero = 100.0;  
        double base = 5.0;     
        
        
        if (numero <= 0 || base <= 0 || base == 1) {
            System.out.println("O número e a base devem ser maiores que zero e a base não pode ser 1.");
            return;
        }
        
        
        double logaritmo = Math.log(numero) / Math.log(base);
        
        
        System.out.printf("O logaritmo de %.2f na base %.2f é %.4f%n", numero, base, logaritmo);
    }
}
