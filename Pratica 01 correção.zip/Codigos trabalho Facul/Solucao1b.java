import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Solucao1b {
    public static void main(String[] args) {
        // Criação de um BufferedReader para ler a entrada do usuário
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        
        try {
            // Leitura do número digitado pelo usuário como uma String
            System.out.print("Digite um numero inteiro: ");
            String input = reader.readLine();
            
            // Conversão da String para um número inteiro
            int numero = Integer.parseInt(input);
            
            // Exibição do valor do número
            System.out.println("O valor do numero digitado é: " + numero);
            
        } catch (IOException e) {
            // Tratamento de exceção para erros de leitura
            System.out.println("Erro ao ler a entrada.");
            e.printStackTrace();
        } catch (NumberFormatException e) {
            // Tratamento de exceção para erro de conversão
            System.out.println("O valor digitado nao e um numero inteiro valido.");
            e.printStackTrace();
        }
    }
}
