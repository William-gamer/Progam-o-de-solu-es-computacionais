public class Solucao1u {
    public static void main(String[] args) {
        double numero = 5; 
        
        
        double quadrado = numero * numero;
        double raizQuadrada = Math.sqrt(numero);


        System.out.println("Numero: " + numero);
        System.out.println("Quadrado: " + quadrado);
        System.out.println("Raiz Quadrada: " + raizQuadrada);
    }
}
