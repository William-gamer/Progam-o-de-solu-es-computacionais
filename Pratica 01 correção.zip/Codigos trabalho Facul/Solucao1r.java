public class Solucao1r {
    public static void main(String[] args) {
        // Definindo os números reais
        double a = 10.5; // Exemplo para 'a'
        double b = 2.0;  // Exemplo para 'b'
        double c = 4.5;  // Exemplo para 'c'

        // Calculando a expressão
        double x = 2 * ((a - c) / 8) - (b * 5);

        // Imprimindo o resultado
        System.out.println("O resultado da expressão e: " + x);
    }
}
