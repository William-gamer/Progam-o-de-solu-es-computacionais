import javax.swing.JOptionPane;

public class Solucao3k {
    public static void main(String[] args) {
        int codigo;
        double consumo;
        int tipo;
        double custo;
        
        double totalResidencial = 0;
        double totalComercial = 0;
        double totalIndustrial = 0;
        int contadorResidencial = 0;
        int contadorComercial = 0;

        while (true) {
           
            codigo = Integer.parseInt(JOptionPane.showInputDialog("Digite o código do consumidor (0 para sair):"));
            if (codigo == 0) {
                break;
            }

            consumo = Double.parseDouble(JOptionPane.showInputDialog("Digite a quantidade de kWh consumidos:"));

            tipo = Integer.parseInt(JOptionPane.showInputDialog("Digite o tipo do consumidor (1 - Residencial, 2 - Comercial, 3 - Industrial):"));


            switch (tipo) {
                case 1:
                    custo = consumo * 0.3;
                    totalResidencial += consumo;
                    contadorResidencial++;
                    break;
                case 2:
                    custo = consumo * 0.5;
                    totalComercial += consumo;
                    contadorComercial++;
                    break;
                case 3:
                    custo = consumo * 0.7;
                    totalIndustrial += consumo;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Tipo inválido! Digite 1, 2 ou 3.");
                    continue;
            }


            JOptionPane.showMessageDialog(null, "Custo total para o consumidor " + codigo + ": R$ " + custo);
        }


        double totalGeral = totalResidencial + totalComercial + totalIndustrial;
        double mediaResidencial = contadorResidencial > 0 ? totalResidencial / contadorResidencial : 0;
        double mediaComercial = contadorComercial > 0 ? totalComercial / contadorComercial : 0;


        String resultado = "Total de consumo Residencial: " + totalResidencial + " kWh\n" +
                           "Total de consumo Comercial: " + totalComercial + " kWh\n" +
                           "Total de consumo Industrial: " + totalIndustrial + " kWh\n" +
                           "Média de consumo Residencial: " + mediaResidencial + " kWh\n" +
                           "Média de consumo Comercial: " + mediaComercial + " kWh\n" +
                           "Total de consumo Geral: " + totalGeral + " kWh\n";

        JOptionPane.showMessageDialog(null, resultado);
    }
}
