import javax.swing.JOptionPane;

public class Solucao3f {
    public static void main(String[] args) {
        double numero;

        while (true) {
            String entrada = JOptionPane.showInputDialog("Digite um número (ou -999 para sair):");
            if (entrada == null) { 
                break;
            }

            numero = Double.parseDouble(entrada);

            if (numero == -999) {
                break; 
            }

            
            if (numero >= 0) {
                double raizQuadrada = Math.sqrt(numero);
                double inverso = 1 / numero;
                JOptionPane.showMessageDialog(null, "Número: " + numero +
                        "\nRaiz Quadrada: " + raizQuadrada +
                        "\nInverso: " + inverso, "Resultado", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Raiz quadrada não definida para números negativos.", "Erro", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
