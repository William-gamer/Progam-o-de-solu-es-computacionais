import javax.swing.JOptionPane;

public class Solucao3o {
    public static void main(String[] args) {
        int maior = Integer.MIN_VALUE; 
        int numero;

        while (true) {
            
            numero = Integer.parseInt(JOptionPane.showInputDialog("Digite um número (ou -9999 para sair):"));

            
            
            if (numero == -9999) {
                break; 
            }

            
            
            if (numero > maior) {
                maior = numero; 
            }
        }

        
        
        if (maior != Integer.MIN_VALUE) {
            JOptionPane.showMessageDialog(null, "O maior número digitado foi: " + maior);
        } else {
            JOptionPane.showMessageDialog(null, "Nenhum número foi digitado.");
        }
    }
}
