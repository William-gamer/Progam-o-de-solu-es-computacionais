import javax.swing.JOptionPane;

public class Solucao3a {
    public static void main(String[] args) {
        StringBuilder numeros = new StringBuilder();
        int i = 100;

        while (i >= 1) {
            numeros.append(i).append("\n");
            i--;
        }

        JOptionPane.showMessageDialog(null, numeros.toString(), "Contagem Regressiva", JOptionPane.INFORMATION_MESSAGE);
    }
}
