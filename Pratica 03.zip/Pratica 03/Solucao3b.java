import javax.swing.JOptionPane;

public class Solucao3b {
    public static void main(String[] args) {
        StringBuilder numerosPares = new StringBuilder();
        int i = 0;
        int contador = 0;

        while (contador < 100) {
            numerosPares.append(i).append("\n");
            i += 2;  
            contador++;
        }

        JOptionPane.showMessageDialog(null, numerosPares.toString(), "100 Primeiros Números Pares", JOptionPane.INFORMATION_MESSAGE);
    }
}
