import javax.swing.JOptionPane;

public class Solucao3m {
    public static void main(String[] args) {
        while (true) {

            int numero = Integer.parseInt(JOptionPane.showInputDialog("Digite um número (ou um número negativo para sair):"));


            if (numero < 0) {
                break; 
            }


            if (isPrimo(numero)) {
                JOptionPane.showMessageDialog(null, numero + " é um número primo.");
            } else {
                JOptionPane.showMessageDialog(null, numero + " não é um número primo.");
            }
        }
        JOptionPane.showMessageDialog(null, "Programa encerrado.");
    }

    public static boolean isPrimo(int num) {
        if (num <= 1) {
            return false; 
        }
        
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false; 
            }
        }
        
        return true; 
    }
}
