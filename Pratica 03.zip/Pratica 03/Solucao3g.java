import javax.swing.JOptionPane;

public class Solucao3g {
    public static void main(String[] args) {
    int i = 1;
    StringBuilder multiplos = new StringBuilder();

        while (i <= 500) {
            if (i % 5 == 0) {
                multiplos.append(i).append("\n");
            }
            i++; 
        }

        JOptionPane.showMessageDialog(null, "Números múltiplos de 5 entre 1 e 500:\n" + multiplos.toString(), "Resultado", JOptionPane.INFORMATION_MESSAGE);
    }
}