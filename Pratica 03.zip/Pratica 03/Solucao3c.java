import javax.swing.JOptionPane;

public class Solucao3c {
    public static void main(String[] args) {
        double soma = 0;
        int contador = 0;
        double numero;

        while (true) {
            String entrada = JOptionPane.showInputDialog("Digite um número positivo(ou negativo para cancelar:");
            if (entrada == null) { 
            break;
            }

            numero = Double.parseDouble(entrada);
            if (numero < 0) {
                break; 
            }

            soma += numero;
            contador++;
        }

        if (contador > 0) {
            double media = soma / contador;
            JOptionPane.showMessageDialog(null, "A média dos números digitados é: " + media, "Resultado", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Nenhum número positivo foi digitado.", "Resultado", JOptionPane.WARNING_MESSAGE);
        }
    }
}
