import javax.swing.JOptionPane;

public class Solucao3i {
    public static void main(String[] args) {
        StringBuilder numeros = new StringBuilder();
        int soma = 0;
        int i = 1;

        while (i <= 100) {
            numeros.append(i).append("\n"); 
            soma += i; 
            i++; 
        }

        
        JOptionPane.showMessageDialog(null, "Números de 1 a 100:\n" + numeros.toString() + "Soma: " + soma, "Resultado", JOptionPane.INFORMATION_MESSAGE);
    }
}
