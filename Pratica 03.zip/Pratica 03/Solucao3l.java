import javax.swing.JOptionPane;

public class Solucao3l {
    public static void main(String[] args) {
        int idade;
        int contMenos21 = 0;
        int contMais50 = 0;

        while (true) {

            idade = Integer.parseInt(JOptionPane.showInputDialog("Digite a idade (ou uma idade fora da faixa 0-120 para sair):"));


            if (idade < 0 || idade > 120) {
                break;
            }


            if (idade < 21) {
                contMenos21++;
            } 
            if (idade > 50) {
                contMais50++;
            }
        }


        String resultado = "Total de pessoas com menos de 21 anos: " + contMenos21 + "\n" +
                           "Total de pessoas com mais de 50 anos: " + contMais50;

        JOptionPane.showMessageDialog(null, resultado);
    }
}
