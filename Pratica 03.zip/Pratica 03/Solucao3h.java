import javax.swing.JOptionPane;
import java.math.BigInteger;

public class Solucao3h {
    public static void main(String[] args) {
        BigInteger produto = BigInteger.ONE; 
        int i = 120;

        do {
            produto = produto.multiply(BigInteger.valueOf(i)); 
            i++; 
        } while (i <= 300);

        
        JOptionPane.showMessageDialog(null, "O produto de todos os números de 120 a 300 é: " + produto, "Resultado", JOptionPane.INFORMATION_MESSAGE);
    }
}
