import javax.swing.JOptionPane;

public class Solucao3d {
    public static void main(String[] args) {
        int contador = 0;
        int numero;

        while (true) {
            String entrada = JOptionPane.showInputDialog("Digite um número (0 para sair):");
            if (entrada == null) { 
                break;
            }

            numero = Integer.parseInt(entrada);

            if (numero == 0) {
                break; 
            }

            
            if (numero >= 100 && numero <= 200) {
                contador++;
            }
        }

        JOptionPane.showMessageDialog(null, "Total de números entre 100 e 200 digitados: " + contador, "Resultado", JOptionPane.INFORMATION_MESSAGE);
    }
}
