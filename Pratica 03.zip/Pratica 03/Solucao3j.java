import javax.swing.JOptionPane;

public class Solucao3j {
    public static void main(String[] args) {
        int numero;

        while (true) {
            String entrada = JOptionPane.showInputDialog("Digite um número (ou -999 para sair):");
            if (entrada == null) { 
                break;
            }

            numero = Integer.parseInt(entrada);

            if (numero == -999) {
                break; 
            }

            
            StringBuilder divisores = new StringBuilder("Divisores de " + numero + ": ");
            for (int i = 1; i <= Math.abs(numero); i++) {
                if (numero % i == 0) {
                    divisores.append(i).append(" ");
                }
            }

            
            JOptionPane.showMessageDialog(null, divisores.toString(), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
