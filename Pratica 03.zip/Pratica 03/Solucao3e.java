import javax.swing.JOptionPane;

public class Solucao3e {
    public static void main(String[] args) {
        String nome;
        
        while (true) {
            nome = JOptionPane.showInputDialog("Digite um nome (ou 'FIM' para encerrar):");
            
            if (nome == null || nome.equalsIgnoreCase("FIM")) {
               break; }
               
               
           JOptionPane.showMessageDialog(null, "Nome digitado: " + nome);
           
        }
    }
}

