public class Turma {
    private String nome;
    private String curso;
    private int quantidadeDeAlunos;
    private int serie;

    public Turma(String nome, String curso, int quantidadeDeAlunos, int serie) {
        this.nome = nome;
        this.curso = curso;
        this.quantidadeDeAlunos = quantidadeDeAlunos;
        this.serie = serie;
    }


    public String getNome() {
        return nome;
    }

    public String getCurso() {
        return curso;
    }

    public int getQuantidadeDeAlunos() {
        return quantidadeDeAlunos;
    }

    public int getSerie() {
        return serie;
    }



    public void setQuantidadeDeAlunos(int quantidadeDeAlunos) {
        this.quantidadeDeAlunos = quantidadeDeAlunos;
    }

    @Override
    public String toString() {
        return "Turma{" +
                "nome='" + nome + '\'' +
                ", curso='" + curso + '\'' +
                ", quantidadeDeAlunos=" + quantidadeDeAlunos +
                ", serie=" + serie +
                '}';
    }
}
 import javax.swing.JOptionPane;

public class TesteTurma {
    public static void main(String[] args) {
        String nome = JOptionPane.showInputDialog("Digite o nome da turma:");
        String curso = JOptionPane.showInputDialog("Digite o curso:");
        int quantidadeDeAlunos = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de alunos:"));
        int serie = Integer.parseInt(JOptionPane.showInputDialog("Digite a série:"));

        Turma turma = new Turma(nome, curso, quantidadeDeAlunos, serie);
        

        quantidadeDeAlunos = Integer.parseInt(JOptionPane.showInputDialog("Digite a nova quantidade de alunos:"));
        turma.setQuantidadeDeAlunos(quantidadeDeAlunos);


        String resultado = turma.toString();
        JOptionPane.showMessageDialog(null, resultado);
    }
}
public class Produto {
    private String nome;
    private double preco;
    private int quantidade;

    public Produto(String nome, double preco, int quantidade) {
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
    }


    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public int getQuantidade() {
        return quantidade;
    }


    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    @Override
    public String toString() {
        return "Produto{" +
                "nome='" + nome + '\'' +
                ", preco=" + preco +
                ", quantidade=" + quantidade +
                '}';
    }
}
 import javax.swing.JOptionPane;

public class TesteProduto {
    public static void main(String[] args) {
        String nome = JOptionPane.showInputDialog("Digite o nome do produto:");
        double preco = Double.parseDouble(JOptionPane.showInputDialog("Digite o preço:"));
        int quantidade = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade:"));

        Produto produto = new Produto(nome, preco, quantidade);

        String resultado = produto.toString();
        JOptionPane.showMessageDialog(null, resultado);
    }
}
public class Disciplina {
    private String nome;
    private String professor;
    private int semestre;
    private boolean ofertada;

    public Disciplina(String nome, String professor, int semestre, boolean ofertada) {
        this.nome = nome;
        this.professor = professor;
        this.semestre = semestre;
        this.ofertada = ofertada;
    }

    public String getNome() {
        return nome;
    }

    public String getProfessor() {
        return professor;
    }

    public int getSemestre() {
        return semestre;
    }

    public boolean isOfertada() {
        return ofertada;
    }

    public void setOfertada(boolean ofertada) {
        this.ofertada = ofertada;
    }

    @Override
    public String toString() {
        return "Disciplina{" +
                "nome='" + nome + '\'' +
                ", professor='" + professor + '\'' +
                ", semestre=" + semestre +
                ", ofertada=" + ofertada +
                '}';
    }
}
 import javax.swing.JOptionPane;

public class TesteDisciplina {
    public static void main(String[] args) {
        String nome = JOptionPane.showInputDialog("Digite o nome da disciplina:");
        String professor = JOptionPane.showInputDialog("Digite o nome do professor:");
        int semestre = Integer.parseInt(JOptionPane.showInputDialog("Digite o semestre:"));
        boolean ofertada = JOptionPane.showConfirmDialog(null, "A disciplina está ofertada?") == JOptionPane.YES_OPTION;

        Disciplina disciplina = new Disciplina(nome, professor, semestre, ofertada);


        String resultado = disciplina.toString();
        JOptionPane.showMessageDialog(null, resultado);
    }
}


