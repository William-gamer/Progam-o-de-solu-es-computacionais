import javax.swing.JOptionPane;

public class Solucao3u {
    public static void main(String[] args) {
       
        int numeroDePessoas = 20;
        
        
        String[] nomes = new String[numeroDePessoas];
        int[] idades = new int[numeroDePessoas];
        String[] sexos = new String[numeroDePessoas];

        
        
        for (int i = 0; i < numeroDePessoas; i++) {
            
            
            nomes[i] = JOptionPane.showInputDialog("Digite o nome da pessoa " + (i + 1) + ":");

            
            String idadeStr = JOptionPane.showInputDialog("Digite a idade da pessoa " + (i + 1) + ":");
            idades[i] = Integer.parseInt(idadeStr);


            sexos[i] = JOptionPane.showInputDialog("Digite o sexo da pessoa " + (i + 1) + " (M/F):").toUpperCase();
        }


        StringBuilder nomesFiltrados = new StringBuilder();


        for (int i = 0; i < numeroDePessoas; i++) {

            if (sexos[i].equals("M") && idades[i] > 21) {
                nomesFiltrados.append(nomes[i]).append("\n"); 
            }
        }


        if (nomesFiltrados.length() > 0) {
            JOptionPane.showMessageDialog(null, "Nomes de homens com mais de 21 anos:\n" + nomesFiltrados.toString());
        } else {
            JOptionPane.showMessageDialog(null, "Não há homens com mais de 21 anos.");
        }
    }
}
