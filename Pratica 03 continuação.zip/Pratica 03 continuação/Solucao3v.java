import javax.swing.JOptionPane;

public class Solucao3v {
    public static void main(String[] args) {

        String limiteStr = JOptionPane.showInputDialog("Digite o limite superior:");


        int limiteSuperior = Integer.parseInt(limiteStr);


        StringBuilder numerosImpares = new StringBuilder();


        for (int i = 1; i < limiteSuperior; i += 2) {
            numerosImpares.append(i).append(", "); 
        }


        if (numerosImpares.length() > 0) {
            numerosImpares.setLength(numerosImpares.length() - 2);
        }


        JOptionPane.showMessageDialog(null, "Números ímpares menores que " + limiteSuperior + ":\n" + numerosImpares.toString());
    }
}
