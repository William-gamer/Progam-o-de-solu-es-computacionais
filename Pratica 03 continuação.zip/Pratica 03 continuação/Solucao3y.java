import javax.swing.JOptionPane;

public class Solucao3y {
    public static void main(String[] args) {

        String num1Str = JOptionPane.showInputDialog("Digite o primeiro número real:");
        String num2Str = JOptionPane.showInputDialog("Digite o segundo número real:");
        
        double num1 = Double.parseDouble(num1Str);
        double num2 = Double.parseDouble(num2Str);
        
        int opcao = 0;


        while (opcao != 9) {

            String menu = "Operações Disponíveis:\n" +
                          "1. Adição\n" +
                          "2. Subtração\n" +
                          "3. Multiplicação\n" +
                          "4. Divisão\n" +
                          "9. Sair do Programa\n" +
                          "Digite o número da opção desejada:";
            
            String opcaoStr = JOptionPane.showInputDialog(menu);
            opcao = Integer.parseInt(opcaoStr);

            double resultado = 0; 


            switch (opcao) {
                case 1: 
                    resultado = num1 + num2;
                    JOptionPane.showMessageDialog(null, "Resultado da Adição: " + resultado);
                    break;
                case 2: 
                    resultado = num1 - num2;
                    JOptionPane.showMessageDialog(null, "Resultado da Subtração: " + resultado);
                    break;
                case 3: 
                    resultado = num1 * num2;
                    JOptionPane.showMessageDialog(null, "Resultado da Multiplicação: " + resultado);
                    break;
                case 4: 
                    if (num2 != 0) {
                        resultado = num1 / num2;
                        JOptionPane.showMessageDialog(null, "Resultado da Divisão: " + resultado);
                    } else {
                        JOptionPane.showMessageDialog(null, "Erro: Divisão por zero não é permitida.");
                    }
                    break;
                case 9:
                    JOptionPane.showMessageDialog(null, "Saindo do programa.");
                    break;
                default: 
                    JOptionPane.showMessageDialog(null, "Opção inválida! Por favor, tente novamente.");
                    break;
            }
        }
    }
}
