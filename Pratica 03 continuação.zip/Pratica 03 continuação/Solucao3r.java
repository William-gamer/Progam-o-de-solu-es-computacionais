import javax.swing.JOptionPane;

public class Solucao3r {
    public static void main(String[] args) {
        
        
        String limiteInferiorStr = JOptionPane.showInputDialog("Digite o limite inferior (em graus Celsius):");
        String limiteSuperiorStr = JOptionPane.showInputDialog("Digite o limite superior (em graus Celsius):");
        String incrementoStr = JOptionPane.showInputDialog("Digite o incremento (em graus Celsius):");

        
        
        double limiteInferior = Double.parseDouble(limiteInferiorStr);
        double limiteSuperior = Double.parseDouble(limiteSuperiorStr);
        double incremento = Double.parseDouble(incrementoStr);

        
        
        StringBuilder tabela = new StringBuilder();
        tabela.append("Tabela de Conversao: Celsius para Fahrenheit\n");
        tabela.append("---------------------------------------------------\n");
        tabela.append("Celsius\tFahrenheit\n");
        tabela.append("---------------------------------------------------\n");

        
        
        for (double celsius = limiteInferior; celsius <= limiteSuperior; celsius += incremento) {
            double fahrenheit = (celsius * 9 / 5) + 32;  
            tabela.append(String.format("%.2f", celsius)).append("\t\t").append(String.format("%.2f", fahrenheit)).append("\n");
        }

        
        
        JOptionPane.showMessageDialog(null, tabela.toString(), "Conversao de Celsius para Fahrenheit", JOptionPane.INFORMATION_MESSAGE);
    }
}
