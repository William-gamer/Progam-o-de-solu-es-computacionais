import javax.swing.JOptionPane;

public class Solucao3p {
    public static void main(String[] args) {
    
        String input = JOptionPane.showInputDialog("Digite um numero:");
        int numero = Integer.parseInt(input);
        
        
        int a = 0, b = 1;
        
        
        StringBuilder sequencia = new StringBuilder();
        
        
        while (a <= numero) {
         sequencia.append(a).append(" ");
            int proximo = a + b;
            a = b;
            b = proximo;
        }
        
        
        JOptionPane.showMessageDialog(null, "Sequência de Fibonacci até " + numero + ":\n" + sequencia.toString());
    }
}