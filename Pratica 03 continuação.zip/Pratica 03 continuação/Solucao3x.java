import javax.swing.JOptionPane;

public class Solucao3x {
    public static void main(String[] args) {
        double total = 0.0;

        while (true) {

            double preco = 0.0;
            while (true) {
                String precoStr = JOptionPane.showInputDialog("Digite o preço da mercadoria (ou 0 para sair):");
                preco = Double.parseDouble(precoStr);
                
                if (preco >= 0) {
                    break; 
                } else {
                    JOptionPane.showMessageDialog(null, "Preço não pode ser negativo. Tente novamente.");
                }
            }


            if (preco == 0) {
                break; 
            }


            int quantidade = -1;
            while (quantidade < 0) {
                String quantidadeStr = JOptionPane.showInputDialog("Digite a quantidade de itens comprados:");
                quantidade = Integer.parseInt(quantidadeStr);
                
                if (quantidade < 0) {
                    JOptionPane.showMessageDialog(null, "Quantidade não pode ser negativa. Tente novamente.");
                }
            }


            total += preco * quantidade; 
            
                    }


        JOptionPane.showMessageDialog(null, "Total a ser pago: R$ " + String.format("%.2f", total));
    }
}
