import javax.swing.JOptionPane;

public class Solucao3w {
    public static void main(String[] args) {

        String entradaStr = JOptionPane.showInputDialog("Quantos numeros pares a partir de 2 você deseja imprimir?");


        int quantidade = Integer.parseInt(entradaStr);


        StringBuilder numerosPares = new StringBuilder();


        for (int i = 1; i <= quantidade; i++) {
            int par = i * 2; 
            numerosPares.append(par).append(", "); 
        }


        if (numerosPares.length() > 0) {
            numerosPares.setLength(numerosPares.length() - 2);
        }


        JOptionPane.showMessageDialog(null, "Numeros pares a partir de 2:\n" + numerosPares.toString());
    }
}
