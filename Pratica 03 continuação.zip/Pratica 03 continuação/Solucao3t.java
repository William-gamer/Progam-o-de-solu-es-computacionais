import javax.swing.JOptionPane;

public class Solucao3t {
    public static void main(String[] args) {
       
       
        String limiteStr = JOptionPane.showInputDialog("Digite o limite superior do intervalo:");
        String incrementoStr = JOptionPane.showInputDialog("Digite o incremento:");

        
        
        int limiteSuperior = Integer.parseInt(limiteStr);
        int incremento = Integer.parseInt(incrementoStr);

        
        
        StringBuilder intervalo = new StringBuilder();

        
        
        for (int i = 0; i <= limiteSuperior; i += incremento) {
            intervalo.append(i).append(", "); 
        }

        
        
        if (intervalo.length() > 0) {
            intervalo.setLength(intervalo.length() - 2);
        }

        
        
        JOptionPane.showMessageDialog(null, "Números do intervalo: " + intervalo.toString());
    }
}
