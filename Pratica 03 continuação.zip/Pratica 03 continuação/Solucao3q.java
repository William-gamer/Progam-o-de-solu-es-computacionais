import javax.swing.JOptionPane;

public class Solucao3q {
    public static void main(String[] args) {
        
        
        final double CONVERSAO = 2.54;

        
        
        StringBuilder tabela = new StringBuilder();
        tabela.append("Tabela de Conversao: Polegadas para Centimetros\n");
        tabela.append("-------------------------------------------------\n");
        tabela.append("Polegadas\tCentimetros\n");
        tabela.append("-------------------------------------------------\n");

        
        
        for (int polegadas = 1; polegadas <= 20; polegadas++) {
            double centimetros = polegadas * CONVERSAO;
            tabela.append(polegadas).append("\t\t").append(String.format("%.2f", centimetros)).append("\n");
        }

        
        
        JOptionPane.showMessageDialog(null, tabela.toString(), "Conversao de Polegadas para Centimetros", JOptionPane.INFORMATION_MESSAGE);
    }
}
