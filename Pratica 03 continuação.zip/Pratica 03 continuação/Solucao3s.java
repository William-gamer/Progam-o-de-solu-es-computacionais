import javax.swing.JOptionPane;

public class Solucao3s {
    public static void main(String[] args) {
    
        String input = JOptionPane.showInputDialog("Digite um número inteiro não negativo para calcular o fatorial:");
        
        
        int numero = Integer.parseInt(input);
        
        
        if (numero < 0) {
        JOptionPane.showMessageDialog(null, "O número deve ser não negativo!", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        
        
        long fatorial = 1;
        for (int i = 1; i <= numero; i++) {
             fatorial *= i;
        }
        
         JOptionPane.showMessageDialog(null, "O fatorial de " + numero + " é: " + fatorial);
    }
}