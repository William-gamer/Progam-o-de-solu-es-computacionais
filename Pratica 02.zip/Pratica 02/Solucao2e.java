import javax.swing.JOptionPane;

public class Solucao2e {
    public static void main(String[] args) {
        try {
            int numero = Integer.parseInt(JOptionPane.showInputDialog("Digite um numero"));
            
            if (numero>= 20 && numero <= 90) {
                JOptionPane.showMessageDialog(null, "O numero " + numero + " esta entre 20 e 90");
            } else {
                JOptionPane.showMessageDialog(null, "O numero " + numero + " nao esta entre 20 e 90");
            }
         } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira um número válido.");
        }
    }
}     
            