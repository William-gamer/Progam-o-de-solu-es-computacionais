import javax.swing.JOptionPane;

public class Solucao2x {
    public static void main(String[] args) {
        int maior = Integer.MIN_VALUE; 
        int menor = Integer.MAX_VALUE;  


        for (int i = 1; i <= 5; i++) {
            String input = JOptionPane.showInputDialog("Digite o " + i + "º número:");
            int numero = Integer.parseInt(input);


            if (numero > maior) {
                maior = numero;
            }
            if (numero < menor) {
                menor = numero;
            }
        }


        String mensagem = "O maior número é: " + maior + "\nO menor número é: " + menor;
        JOptionPane.showMessageDialog(null, mensagem);
    }
}
