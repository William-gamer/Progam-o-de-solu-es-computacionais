import javax.swing.JOptionPane;

public class Solucao2n {
    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog("Digite um número inteiro de 4 dígitos:");

        try {
            int numero = Integer.parseInt(input);
            
            if (numero < 1000 || numero > 9999) {
                JOptionPane.showMessageDialog(null, "Por favor, insira um número de 4 dígitos.");
                return;
            }
            
            int milhar = numero / 1000;
            int centena = (numero / 100) % 10;

            int novoNumero = milhar * 10 + centena;

            boolean ehMultiploDeQuatro = (novoNumero % 4 == 0);
            
            String resultado = ehMultiploDeQuatro ? "é múltiplo de 4." : "não é múltiplo de 4.";
            JOptionPane.showMessageDialog(null, "O número formado é " + novoNumero + " e " + resultado);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira um número válido.");
        }
    }
}
