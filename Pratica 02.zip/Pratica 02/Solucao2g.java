import javax.swing.JOptionPane;

public class Solucao2g {
    public static void main(String[] args) {
        String nome = JOptionPane.showInputDialog("Digite seu nome:");
        char sexo = JOptionPane.showInputDialog("Digite seu sexo (f para feminino, m para masculino):").charAt(0);
        int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite sua idade:"));

        if ((sexo == 'f' || sexo == 'F') && idade < 18) {
            JOptionPane.showMessageDialog(null, nome + ", ACEITA.");
        } else {
            JOptionPane.showMessageDialog(null, nome + ", NÃO ACEITA.");
        }
    }
}
