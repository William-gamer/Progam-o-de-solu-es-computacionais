import javax.swing.JOptionPane;

public class Solucao2m {
    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog("Digite um número inteiro de 3 dígitos:");

        try {
            int numero = Integer.parseInt(input);
            
            if (numero < 100 || numero > 999) {
                JOptionPane.showMessageDialog(null, "Por favor, insira um número de 3 dígitos.");
                return;
            }
            
            int dezenas = (numero / 10) % 10;

            String parOuImpar = (dezenas % 2 == 0) ? "par" : "ímpar";
            
            JOptionPane.showMessageDialog(null, "O algarismo da casa das dezenas é " + parOuImpar + ".");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira um número válido.");
        }
    }
}
