import javax.swing.JOptionPane;

public class Solucao2b {
    public static void main(String[] args) {
        try {
            int num1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o primeiro número:"));
            int num2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o segundo número:"));
            
            int soma = num1 + num2;

            if (soma <= 20) {
                soma -= 5; 
            }

            JOptionPane.showMessageDialog(null, "O resultado é: " + soma);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira apenas números inteiros.");
        }
    }
}
