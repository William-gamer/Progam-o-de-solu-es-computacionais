import javax.swing.JOptionPane;

public class Solucao2a {
    public static void main(String[] args) {
        int a = Integer.parseInt(JOptionPane.showInputDialog("Digite o primeiro valor:"));
        int b = Integer.parseInt(JOptionPane.showInputDialog("Digite o segundo valor:"));
        int soma = a + b;

        if (soma > 10) {
            
            int resultado = soma;
        }
    }
}


