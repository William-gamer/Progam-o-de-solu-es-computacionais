import javax.swing.JOptionPane;

public class Solucao2o {
    public static void main(String[] args) {
        String anoNascimentoStr = JOptionPane.showInputDialog("Digite o ano de nascimento:");
        String anoAtualStr = JOptionPane.showInputDialog("Digite o ano atual:");

        try {
            int anoNascimento = Integer.parseInt(anoNascimentoStr);
            int anoAtual = Integer.parseInt(anoAtualStr);

            if (anoNascimento <= 0 || anoAtual < anoNascimento) {
                JOptionPane.showMessageDialog(null, "Ano de nascimento inválido.");
            } else {
                int idade = anoAtual - anoNascimento;
                JOptionPane.showMessageDialog(null, "A idade da pessoa é: " + idade + " anos.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira um ano válido.");
        }
    }
}
