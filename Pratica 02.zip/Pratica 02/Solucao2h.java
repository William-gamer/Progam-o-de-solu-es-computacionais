import javax.swing.JOptionPane;

public class Solucao2h {
    public static void main(String[] args) {
        try {
            int num1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o primeiro número:"));
            int num2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o segundo número:"));

            int maior = (num1 > num2) ? num1 : num2;

            JOptionPane.showMessageDialog(null, "O maior número é: " + maior);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira apenas números válidos.");
        }
    }
}
