import javax.swing.JOptionPane;

public class Solucao2q {
    public static void main(String[] args) {
        String input1 = JOptionPane.showInputDialog("Digute o primeiro numero");
        String input2 = JOptionPane.showInputDialog("Digute o segundo numero");
        
        int numero1 = Integer.parseInt(input1);
        int numero2 = Integer.parseInt(input2);

        int menor = (numero1 < numero2) ? numero1 : numero2;

        JOptionPane.showMessageDialog(null, "O menor número é: " + menor);
    }
}
       