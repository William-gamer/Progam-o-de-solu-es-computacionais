import javax.swing.JOptionPane;

public class Solucao2k {
    public static void main(String[] args) {
        // Solicitar ao usuário para inserir um número
        String input = JOptionPane.showInputDialog("Digite um número:");
        
        try {
            // Converter a entrada para um inteiro
            int numero = Integer.parseInt(input);
            
            // Verificar divisibilidade
            boolean divisivelPor3 = (numero % 3 == 0);
            boolean divisivelPor7 = (numero % 7 == 0);
            
            // Criar uma mensagem de resultado
            StringBuilder resultado = new StringBuilder("O número " + numero + " é:");
            if (divisivelPor3) {
                resultado.append(" divisível por 3.");
            } else {
                resultado.append(" não é divisível por 3.");
            }
            if (divisivelPor7) {
                resultado.append(" divisível por 7.");
            } else {
                resultado.append(" não é divisível por 7.");
            }
            
            // Exibir a mensagem
            JOptionPane.showMessageDialog(null, resultado.toString());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira um número válido.");
        }
    }
}
