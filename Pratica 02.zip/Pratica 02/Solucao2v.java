import javax.swing.JOptionPane;

public class Solucao2v {
    public static void main(String[] args) {
        String input1 = JOptionPane.showInputDialog("Digite o primeiro número:");
        String input2 = JOptionPane.showInputDialog("Digite o segundo número:");
        String input3 = JOptionPane.showInputDialog("Digite o terceiro número:");

        int num1 = Integer.parseInt(input1);
        int num2 = Integer.parseInt(input2);
        int num3 = Integer.parseInt(input3);

        int maior = num1;

        if (num2 > maior) {
            maior = num2;
        }

        if (num3 > maior) {
            maior = num3;
        }

        JOptionPane.showMessageDialog(null, "O maior número é: " + maior);
    }
}
