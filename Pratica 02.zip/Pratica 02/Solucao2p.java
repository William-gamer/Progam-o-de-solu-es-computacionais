import javax.swing.JOptionPane;

public class Solucao2p {
    public static void main(String[] args) {
        String input1 = JOptionPane.showInputDialog("Digite o primeiro numero:");
        String input2 = JOptionPane.showInputDialog("Digite o segundo numero:");
        
        int numero1 = Integer.parseInt(input1);
        int numero2 = Integer.parseInt(input2);
     
     if (numero1 == numero2) {
            JOptionPane.showMessageDialog(null, "Os números são iguais.");
        } else {
            JOptionPane.showMessageDialog(null, "Os números são diferentes.");
        }
    }
}