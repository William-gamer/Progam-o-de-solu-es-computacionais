import javax.swing.JOptionPane;

public class Solucao2c {
    public static void main(String[] args) {
        try {
            double numero = Double.parseDouble(JOptionPane.showInputDialog("Digite um número:"));
            
            if (numero > 0) {
                double raizQuadrada = Math.sqrt(numero);
                JOptionPane.showMessageDialog(null, "A raiz quadrada de " + numero + " é: " + raizQuadrada);
            } else {
                double quadrado = numero * numero;
                JOptionPane.showMessageDialog(null, "O quadrado de " + numero + " é: " + quadrado);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira um número válido.");
        }
    }
}
