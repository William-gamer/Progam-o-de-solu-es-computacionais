import javax.swing.JOptionPane;

public class Solucao2i {
    public static void main(String[] args) {
        try {
            int numero = Integer.parseInt(JOptionPane.showInputDialog("Digite um número:"));

            if (numero % 3 == 0) {
                JOptionPane.showMessageDialog(null, "O número " + numero + " é múltiplo de 3.");
            } else {
                JOptionPane.showMessageDialog(null, "O número " + numero + " não é múltiplo de 3.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira um número válido.");
        }
    }
}


            
