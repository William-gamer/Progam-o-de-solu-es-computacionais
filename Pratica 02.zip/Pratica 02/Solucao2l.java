import javax.swing.JOptionPane;

public class Solucao2l {
    public static void main(String[] args) {
        
        String input = JOptionPane.showInputDialog("Digite um número:");
        
        try {
            
            int numero = Integer.parseInt(input);
            
            boolean divisivelPor10 = (numero % 10 == 0);
            boolean divisivelPor5 = (numero % 5 == 0);
            boolean divisivelPor2 = (numero % 2 == 0);
            
            StringBuilder resultado = new StringBuilder("O número " + numero + " é:");
            if (divisivelPor10) {
                resultado.append(" divisível por 10.");
            } else if (divisivelPor5) {
                resultado.append(" divisível por 5.");
            } else if (divisivelPor2) {
                resultado.append(" divisível por 2.");
            } else {
                resultado.append(" não é divisível por 10, 5 ou 2.");
            }
            
            JOptionPane.showMessageDialog(null, resultado.toString());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira um número válido.");
        }
    }
}
