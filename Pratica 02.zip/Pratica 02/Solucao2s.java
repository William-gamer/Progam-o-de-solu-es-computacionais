import javax.swing.JOptionPane;

public class Solucao2s {
    public static void main(String[] args) {
        String input1 = JOptionPane.showInputDialog("Digite o primeiro número:");
        String input2 = JOptionPane.showInputDialog("Digite o segundo número:");

        int numero1 = Integer.parseInt(input1);
        int numero2 = Integer.parseInt(input2);

        String resultado;
        if (numero1 > numero2) {
            resultado = "Ordem decrescente: " + numero1 + ", " + numero2;
        } else {
            resultado = "Ordem decrescente: " + numero2 + ", " + numero1;
        }

        JOptionPane.showMessageDialog(null, resultado);
    }
}
