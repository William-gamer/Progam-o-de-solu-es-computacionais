import javax.swing.JOptionPane;

public class Solucao2d {
    public static void main(String[] args) {
        try {
            int num1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o primeiro número:"));
            int num2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o segundo número:"));
            int num3 = Integer.parseInt(JOptionPane.showInputDialog("Digite o terceiro número:"));

            int maior, medio, menor;

            if (num1 > num2) {
                if (num1 > num3) {
                    maior = num1;
                    medio = Math.max(num2, num3);
                    menor = Math.min(num2, num3);
                } else {
                    maior = num3;
                    medio = num1;
                    menor = num2;
                }
            } else {
                if (num2 > num3) {
                    maior = num2;
                    medio = Math.max(num1, num3);
                    menor = Math.min(num1, num3);
                } else {
                    maior = num3;
                    medio = num2;
                    menor = num1;
                }
            }

            String resultado = "Números em ordem crescente: " + menor + ", " + medio + ", " + maior;
            JOptionPane.showMessageDialog(null, resultado);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor, insira apenas números inteiros.");
        }
    }
}

          